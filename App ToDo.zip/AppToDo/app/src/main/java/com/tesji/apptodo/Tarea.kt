package com.tesji.apptodo

data class Tarea(
    var id: Int,
    var titulo: String,
    var descripcion: String
)